# WDS WP REST API Connect UI Assets #
http://webdevstudios.com
Copyright (c) 2015 WebDevStudios
Licensed under the GPLv2 license.

Assets such as styles, javascript, and images.