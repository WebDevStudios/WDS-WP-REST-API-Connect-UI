# WDS WP REST API Connect UI Includes #
http://webdevstudios.com
Copyright (c) 2015 WebDevStudios
Licensed under the GPLv2 license.

Additional PHP functionality goes here.